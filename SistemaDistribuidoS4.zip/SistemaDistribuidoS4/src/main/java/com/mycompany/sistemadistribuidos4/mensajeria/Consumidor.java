package com.mycompany.sistemadistribuidos4.mensajeria;

import com.mycompany.sistemadistribuidos4.modelo.Compra;
import com.mycompany.sistemadistribuidos4.modelo.Venta;
import org.apache.activemq.ActiveMQConnectionFactory;
import javax.jms.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Consumidor {
    
    // ⚠️ AQUÍ ESTÁ TU CONTRASEÑA DE MYSQL
    private static final String DB_URL = "jdbc:mysql://localhost:3306/distribuidora_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "Powder2026*"; 

    public static void main(String[] args) throws Exception {
        String brokerURL = "tcp://localhost:61616";
        ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(brokerURL);

        // ✅ LÍNEA CORREGIDA: Agregamos "java.util" para autorizar las fechas (Date)
        factory.setTrustedPackages(java.util.Arrays.asList("com.mycompany.sistemadistribuidos4.modelo", "java.util"));

        // Aquí usamos javax.jms.Connection explícitamente
        javax.jms.Connection connection = factory.createConnection();
        connection.start();
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Destination destination = session.createQueue("ColaTransacciones");
        MessageConsumer consumer = session.createConsumer(destination);

        System.out.println("✅ Consumidor iniciado. Esperando transacciones en la cola...");

        while (true) {
            Message message = consumer.receive();
            if (message instanceof ObjectMessage) {
                ObjectMessage objMsg = (ObjectMessage) message;
                Object obj = objMsg.getObject();

                if (obj instanceof Venta) {
                    Venta v = (Venta) obj;
                    System.out.println("💰 VENTA recibida | Producto ID: " + v.getIdProducto() + " | Cantidad: " + v.getCantidad());
                    guardarEnBD("VENTA", v.getIdSucursal(), v.getIdProducto(), v.getCantidad(), v.getPrecioUnitario());
                } else if (obj instanceof Compra) {
                    Compra c = (Compra) obj;
                    System.out.println("📦 COMPRA recibida | Producto ID: " + c.getIdProducto() + " | Cantidad: " + c.getCantidad());
                    guardarEnBD("COMPRA", c.getIdSucursal(), c.getIdProducto(), c.getCantidad(), c.getPrecioUnitario());
                }
            }
        }
    }

    private static void guardarEnBD(String tipo, int idSucursal, int idProducto, int cantidad, double precio) {
        String sql = "INSERT INTO Movimientos (id_sucursal, id_producto, tipo, cantidad, precio_unitario) VALUES (?, ?, ?, ?, ?)";
        
        // Aquí usamos java.sql.Connection explícitamente
        try (java.sql.Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idSucursal);
            pstmt.setInt(2, idProducto);
            pstmt.setString(3, tipo);
            pstmt.setInt(4, cantidad);
            pstmt.setDouble(5, precio);
            pstmt.executeUpdate();
            
            System.out.println("   -> Guardado exitosamente en MySQL.");
        } catch (Exception e) {
            System.err.println("   ❌ Error al guardar en MySQL: " + e.getMessage());
        }
    }
}