package com.mycompany.sistemadistribuidos4.modelo;

import java.io.Serializable;
import java.util.Date;

public class Transaccion implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int id;
    private Date fechaHora;
    private int idSucursal;

    public Transaccion(int id, int idSucursal) {
        this.id = id;
        this.idSucursal = idSucursal;
        this.fechaHora = new Date();
    }

    public int getId() { return id; }
    public Date getFechaHora() { return fechaHora; }
    public int getIdSucursal() { return idSucursal; }
}