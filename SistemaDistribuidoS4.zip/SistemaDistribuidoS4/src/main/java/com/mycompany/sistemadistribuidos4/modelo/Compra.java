package com.mycompany.sistemadistribuidos4.modelo;

public class Compra extends Transaccion {
    private static final long serialVersionUID = 1L;
    
    private int idProducto;
    private int cantidad;
    private double precioUnitario;

    public Compra(int id, int idSucursal, int idProducto, int cantidad, double precioUnitario) {
        super(id, idSucursal);
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    public int getIdProducto() { return idProducto; }
    public int getCantidad() { return cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }
}