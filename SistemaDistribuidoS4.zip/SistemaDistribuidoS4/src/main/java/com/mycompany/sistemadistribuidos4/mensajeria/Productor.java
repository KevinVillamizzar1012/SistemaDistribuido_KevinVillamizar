package com.mycompany.sistemadistribuidos4.mensajeria;

import com.mycompany.sistemadistribuidos4.modelo.Venta;
import org.apache.activemq.ActiveMQConnectionFactory;
import javax.jms.*;

public class Productor {
    public static void main(String[] args) {
        // URL del servidor ActiveMQ (por defecto en el puerto 61616)
        String brokerURL = "tcp://localhost:61616";
        ConnectionFactory factory = new ActiveMQConnectionFactory(brokerURL);

        try (Connection connection = factory.createConnection()) {
            connection.start();

            // Creamos la sesión
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            
            // Creamos la cola donde se enviarán los mensajes
            Destination destination = session.createQueue("ColaTransacciones");
            MessageProducer producer = session.createProducer(destination);

            // --- AQUÍ CREAMOS LA TRANSACCIÓN DE PRUEBA ---
            // Simulamos una venta: ID, ID Sucursal, ID Producto, Cantidad, Precio
            Venta venta = new Venta(1, 2, 1, 50, 3500.00);

            // Empaquetamos el objeto en un mensaje
            ObjectMessage message = session.createObjectMessage();
            message.setObject(venta);

            System.out.println("Enviando transacción de Venta...");
            producer.send(message);
            System.out.println("¡Mensaje enviado con éxito a la cola!");

        } catch (JMSException e) {
            System.err.println("Error en el Productor: " + e.getMessage());
        }
    }
}